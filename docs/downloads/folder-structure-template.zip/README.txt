FOLDER STRUCTURE TEMPLATE

This free template is a starting layout. It does not sort, move, or rename files.
Extract it into a new, empty location of your choice. If any folder name already exists there, review your existing structure and adapt the names yourself; do not overwrite or merge folders automatically.

Work       - active projects, clients, or courses
Personal   - household and personal records
Finance    - receipts, statements, and tax records
Reference  - material you keep for lookup
Archive    - completed work or older records you still need

Keep only categories you use. Add project, person, or year subfolders when they make a file easier to find. Move files in small batches after checking their contents and destination. Keep a separate backup before large moves or renames.

FILENAME SUGGESTIONS (examples only; not Foldora output)
2026-11_project-proposal_v1.docx
2026-11_receipt-office-supplies.pdf
client-name_meeting-notes_2026-11-08.txt

Choose a naming pattern you can use consistently. These are manual examples and do not predict any folder or filename Foldora will suggest.